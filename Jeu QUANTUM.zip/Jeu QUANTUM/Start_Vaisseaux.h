#ifndef START_VAISSEAUX_H_INCLUDED
#define START_VAISSEAUX_H_INCLUDED


void Initialisation_Vaisseaux (S_Joueur tab_Joueurs[], int NbJ);
void Creation_Vaisseaux (S_Joueur tab_Joueurs[], int i);


#endif // START_VAISSEAUX_H_INCLUDED
