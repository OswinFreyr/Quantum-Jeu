#ifndef AFFICHAGE_H_INCLUDED
#define AFFICHAGE_H_INCLUDED


void Affichage_Joueur (S_Joueur tab_Joueurs[], int NbJ);
void Affichage_Joueurs (S_Joueur tab_Joueurs[], int NbJ);
void Affichage_Plateau (S_Case tab_Plateau[9][9], S_Joueur tab_Joueurs[], int NbJ, int J1);


#endif // AFFICHAGE_H_INCLUDED
