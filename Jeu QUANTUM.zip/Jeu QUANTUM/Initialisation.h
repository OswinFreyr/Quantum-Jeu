#ifndef INITIALISATION_H_INCLUDED
#define INITIALISATION_H_INCLUDED


void Initialisation_Joueur (S_Joueur tab_Joueurs[], int NbJ);
void Initialisation_Joueurs (S_Joueur tab_Joueurs[], int NbJ);
void Initialisation_Plateau (S_Case tab_Plateau[9][9], int NbJ);


#endif // INITIALISATION_H_INCLUDED
