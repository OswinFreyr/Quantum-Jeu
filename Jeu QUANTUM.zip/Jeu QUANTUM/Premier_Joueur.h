#ifndef PREMIER_JOUEUR_H_INCLUDED
#define PREMIER_JOUEUR_H_INCLUDED


int Determination_1er_Joueur (S_Joueur tab_Joueurs[], int NbJ);
int Egalite_2 (S_Joueur tab_Joueurs[], int i, int j);
int Egalite_3 (S_Joueur tab_Joueurs[], int i, int j, int k);
int Egalite_4 (S_Joueur tab_Joueurs[], int i, int j, int k, int l);


#endif // PREMIER_JOUEUR_H_INCLUDED
