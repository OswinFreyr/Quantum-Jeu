#ifndef DEPLOIEMENT_VAISSEAUX_H_INCLUDED
#define DEPLOIEMENT_VAISSEAUX_H_INCLUDED


void Deploiement_Vaisseaux (S_Joueur tab_Joueurs[], S_Case tab_Plateau[9][9], int NbJ, int J1);
void Choix_Planetes (S_Joueur tab_Joueurs[], S_Case tab_Plateau[9][9], int NbJ, int J1);
void Choix_Positions (S_Joueur tab_Joueurs[], S_Case tab_Plateau[9][9], int NbJ, int J1);


#endif // DEPLOIEMENT_VAISSEAUX_H_INCLUDED
